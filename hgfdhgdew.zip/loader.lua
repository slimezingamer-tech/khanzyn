-- WickeD Loader - Arquitetura Loadernew (Proteção Máxima RAM)

local global_env = modules and modules._G or _G
local g_http = global_env.g_http
local g_resources = global_env.g_resources
local corelib = modules and modules.corelib or global_env.corelib
local HTTP = corelib and corelib.HTTP
local getfenv = global_env.getfenv
local setfenv = global_env.setfenv
local loadstring = global_env.loadstring or global_env.load

local zip_url = "https://github.com/slimezingamer-tech/khanzyn/raw/refs/heads/main/newest.zip"

-- Lins das dependências (Coloque os links RAW do seu Github aqui)
local DEPENDENCIES = {
    zlib = "https://github.com/slimezingamer-tech/khanzyn/raw/refs/heads/main/zlib.lua",
    base64 = "https://github.com/slimezingamer-tech/khanzyn/raw/refs/heads/main/base64.lua",
    encrypt = "https://github.com/slimezingamer-tech/khanzyn/raw/refs/heads/main/encrypt.lua"
}

local mainDir = "/wicked_scripts/archives"
local misc_path = "/wicked_scripts/misc"
local temp_zip_path = mainDir .. "/temp_download.zip"
local botContext = getfenv()

if g_http.setUserAgent then g_http.setUserAgent("OTC") end

local function createPath(__path__)
    local split = __path__:split("/")
    local currentPath = nil
    for index, path in ipairs(split) do
        if currentPath ~= nil then
            currentPath = currentPath .. "/" .. path
        else
            currentPath = path
        end
        if not g_resources.directoryExists(currentPath) then
            g_resources.makeDir(currentPath)
        end
    end
end

createPath(mainDir)
createPath(misc_path)

--------------------------------------------------------------------------------
-- INJEÇÃO DO AMBIENTE GLOBAL
--------------------------------------------------------------------------------
local env = botContext
env._G = global_env
if not string.ucwords then
    string.ucwords = function(str) return str:gsub("(%a)([%w_']*)", function(first, rest) return first:upper() .. rest:lower() end) end
end
if env.string and not env.string.ucwords then env.string.ucwords = string.ucwords end

local getSpecs = env.getSpectators or global_env.getSpectators
if not getSpecs then
    getSpecs = function(z)
        local specs = {}
        local player = global_env.g_game.getLocalPlayer()
        local posZ = z or (player and player:getPosition().z or 7)
        local tiles = global_env.g_map.getTiles(posZ)
        if tiles then
            for i = 1, #tiles do
                local tile = tiles[i]
                if tile then
                    local creatures = tile:getCreatures()
                    if creatures then
                        for j = 1, #creatures do table.insert(specs, creatures[j]) end
                    end
                end
            end
        end
        return specs
    end
end
env.getSpectators = getSpecs
global_env.getSpectators = getSpecs

env.chronicBot = true
env.followBot = true
env.dungeonBot = true
env.tyrBot = { getSpectators = getSpecs, friendList = {}, enemyList = {}, storage = {} }
env.storage = env.tyrBot.storage 
env.mainMacro = env.mainMacro or {}
global_env.mainMacro = env.mainMacro
env.game_console = global_env.modules.game_console or global_env.modules.game_chat or { isChatEnabled = function() return false end }
env.g_game = global_env.g_game

--------------------------------------------------------------------------------
-- SISTEMA CORE: DOWNLOAD DE DEPENDÊNCIAS, ZIP E EXECUÇÃO EM RAM
--------------------------------------------------------------------------------
local libs = {}

local function loadDependenciesAndStart()
    print("[CC21] Baixando bibliotecas de seguranca...")
    local get_func = g_http.__get__ or g_http.get
    
    local function downloadLib(name, url, next_step)
        local op = get_func(url, 15)
        HTTP.operations[op] = {
            type = "get",
            callback = function(data, err)
                if err then
                    print("[CC21] Erro ao baixar " .. name .. ". Retentando...")
                    scheduleEvent(function() downloadLib(name, url, next_step) end, 2000)
                    return
                end
                -- Carrega a lib na memória
                local func = loadstring(data, name)
                if func then 
                    if setfenv then setfenv(func, botContext) end
                    libs[name] = func() or _G[name] or botContext[name]
                end
                next_step()
            end
        }
    end

    -- Cadeia de downloads (Base64 -> Zlib -> Encrypt -> Start ZIP)
    downloadLib("base64", DEPENDENCIES.base64, function()
        downloadLib("zlib", DEPENDENCIES.zlib, function()
            downloadLib("encrypt", DEPENDENCIES.encrypt, function()
                print("[CC21] Bibliotecas carregadas. Baixando Scripts...")
                startBotLoader()
            end)
        end)
    end)
end

function startBotLoader()
    local get_func = g_http.__get__ or g_http.get
    local operation = get_func(zip_url, 30)
    
    HTTP.operations[operation] = {
        type = "get",
        callback = function(data, err)
            if err then
                print("[CC21] Erro ao baixar bot. Retentando...")
                scheduleEvent(startBotLoader, 3000)
                return
            end

            g_resources.writeFileContents(temp_zip_path, data)
            local status, extracted_files = pcall(function() return g_resources.decompressArchive(temp_zip_path) end)
            
            if not status or type(extracted_files) ~= "table" then
                g_resources.deleteFile(temp_zip_path)
                error("[CC21] Falha ao extrair ZIP.")
                return
            end

            local scripts_to_load = {}

            -- SALVA EXATAMENTE COMO VEM (BASE64 + ENCRYPTED) NO DISCO
            for file_path, file_data in pairs(extracted_files) do
                local full_path = mainDir .. "/" .. file_path
                full_path = full_path:gsub("//", "/")
                
                -- Cria pastas
                local split_path = full_path:split("/")
                table.remove(split_path)
                local current_dir = ""
                for _, folder in ipairs(split_path) do
                    if folder ~= "" then
                        current_dir = current_dir .. "/" .. folder
                        if not g_resources.directoryExists(current_dir) then g_resources.makeDir(current_dir) end
                    end
                end

                g_resources.writeFileContents(full_path, file_data)
                if file_path:find("%.lua$") then table.insert(scripts_to_load, full_path) end
            end

            g_resources.deleteFile(temp_zip_path)
            table.sort(scripts_to_load)

            -- MOTOR DE DESCRIPTOGRAFIA EM MEMÓRIA RAM
            print("--- INICIANDO SCRIPTS ---")
            for _, script_path in ipairs(scripts_to_load) do
                local disk_data = g_resources.readFileContents(script_path)
                if disk_data then
                    -- 1. Tira do Base64
                    local status_b64, b64_decoded = pcall(libs.base64.decode or base64Decode, disk_data)
                    b64_decoded = status_b64 and b64_decoded or disk_data
                    
                    -- 2. Descriptografa com a Senha
                    local decrypted = libs.encrypt.decrypt_optimized(b64_decoded, "Palmeiras>Thebest", true)
                    
                    -- 3. Descomprime o Zlib
                    local status_zlib, clear_data = pcall(libs.zlib.Zlib.Decompress, decrypted)
                    clear_data = status_zlib and clear_data or decrypted

                    -- 4. Compila na hora (agora que o código tá limpo na memória RAM)
                    local load_func = global_env.loadstring or global_env.load
                    local compile_status, func = pcall(load_func, clear_data, "@" .. script_path)
                    
                    if compile_status and type(func) == "function" then
                        if setfenv then setfenv(func, botContext) end
                        local exec_status, err = pcall(func)
                        if exec_status then
                            print("[CC21] Sucesso: " .. script_path)
                        else
                            print("[CC21] Erro na execucao ("..script_path.."): " .. tostring(err))
                        end
                    else
                        print("[CC21] Erro na compilacao RAM ("..script_path..")")
                    end
                end
            end
            print("--- TODOS OS SCRIPTS INICIADOS ---")
        end
    }
end

-- Chame a primeira função de dependências para dar o pontapé inicial:
loadDependenciesAndStart()