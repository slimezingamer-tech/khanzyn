-- auauau

modules._G.g_http.setUserAgent("OTC")

local mainDir = "/wicked_scripts/archives"
local misc_path = "/wicked_scripts/misc"

if DEBUG_INFO ~= nil then print("Debug mode is on.") end

_G = modules._G
_G.debug.sethook()

local addEvent = _G.addEvent
local scheduleEvent = _G.scheduleEvent
local g_resources = _G.g_resources

local createPath = function(__path__)
	local split = __path__:split("/")
	local currentPath = nil
	for index, path in ipairs(split) do
		if currentPath ~= nil then
			currentPath = tr("%s/%s", currentPath, path)
		else
			currentPath = path
		end
		g_resources.makeDir(currentPath)
	end
end

local pcall = _G.pcall
local getfenv = _G.getfenv
local setfenv = _G.setfenv
local loadstring = _G.loadstring or _G.load
local botContext = getfenv()

createPath(misc_path)

--------------------------------------------------------------------------------
-- INJEÇÃO DOS UTENSÍLIOS NO AMBIENTE
--------------------------------------------------------------------------------
local env = botContext
env._G = _G

if not string.ucwords then
	string.ucwords = function(str)
		return str:gsub("(%a)([%w_']*)", function(first, rest) return first:upper() .. rest:lower() end)
	end
end
if env.string and not env.string.ucwords then env.string.ucwords = string.ucwords end

if not table.find then
	table.find = function(t, val)
		for k, v in pairs(t) do if v == val then return k end end return nil
	end
end

local getSpecs = env.getSpectators or _G.getSpectators
if not getSpecs then
	getSpecs = function(z)
		local specs = {}
		local player = _G.g_game.getLocalPlayer()
		local posZ = z or (player and player:getPosition().z or 7)
		local tiles = _G.g_map.getTiles(posZ)
		if tiles then
			for i = 1, #tiles do
				local tile = tiles[i]
				if tile then
					local creatures = tile:getCreatures()
					if creatures then
						for j = 1, #creatures do table.insert(specs, creatures[j]) end
					end
				end
			end
		end
		return specs
	end
end
env.getSpectators = getSpecs
_G.getSpectators = getSpecs

env.chronicBot = true
env.followBot = true
env.dungeonBot = true
env.FREE_VERSION = false
env.CHRONIC_VERSION = true

env.tyrBot = {
	getSpectators = getSpecs,
	getCreatureById = env.getCreatureById or _G.getCreatureById,
	friendList = {},
	enemyList = {},
	storage = {}
}

env.storage = env.tyrBot.storage 
env.mainMacro = env.mainMacro or {}
_G.mainMacro = env.mainMacro

env.game_console = _G.modules.game_console or _G.modules.game_chat or { isChatEnabled = function() return false end }
env.g_game = _G.g_game

env.zoomIn = function() return _G.modules.game_interface.getMapPanel():zoomIn() end
env.zoomOut = function() return _G.modules.game_interface.getMapPanel():zoomOut() end
env.yell = function(text) _G.g_game.talkChannel(3, 0, text) end
env.talkChannel = function(channel, text) _G.g_game.talkChannel(7, channel, text) end
env.sayChannel = env.talkChannel
env.talkPrivate = function(receiver, text) _G.g_game.talkPrivate(5, receiver, text) end
env.sayPrivate = env.talkPrivate
env.talkNpc = function(text) 
	if _G.g_game.getClientVersion() >= 810 then _G.g_game.talkChannel(11, 0, text) else _G.g_game.talk(text) end 
end
env.sayNpc = env.talkNpc

--------------------------------------------------------------------------------
-- SISTEMA DE REQUISIÇÕES HTTP
--------------------------------------------------------------------------------
local g_http = _G.modules.g_http or _G.g_http
local corelib = _G.modules.corelib or _G.corelib
local HTTP = corelib.HTTP

local post = g_http.post
local get = g_http.get
local download = g_http.download

if not g_http.__post__ then
	g_http.__post__ = post
	g_http.__get__ = get
	g_http.__download__ = download
end

local doHttpGet = function(url, callback)
	if url:sub(1, 4) ~= "http" then return end
	local operation = get(url, 15)
	HTTP.operations[operation] = { type = "get", callback = callback }
	return operation
end

local doHttpDownload = function(url, file, callback, progressCallback)
	if url:sub(1, 4) ~= "http" then return end
	local operation = download(url, file, 15)
	HTTP.operations[operation] = { type = "download", callback = callback, progressCallback = progressCallback }
	return operation
end

--------------------------------------------------------------------------------
-- CRIPTOGRAFIA AVANÇADA EMBUTIDA (Seu encrypt.lua)
--------------------------------------------------------------------------------
local function advanced_decrypt(data, password)
    local len = #data
    local result = {}
    local password_bytes = {password:byte(1, -1)}
    local plen = #password_bytes
    local j = 1
    
    for i = 1, len do
        local byte = data:byte(i)
        -- Decrypt logic from your encrypt.lua
        if i % 2 == 0 then
            byte = (byte - password_bytes[j] + i) % 256
        else
            byte = (byte + password_bytes[j] - i) % 256
        end
        result[i] = string.char(byte)
        j = j + 1
        if j > plen then j = 1 end
    end
    return table.concat(result)
end

local look_up = {}
look_up.userInfo = "Palmeiras>Thebest"

look_up.decryptBuffer = function(buffer, key)
	key = key or look_up.userInfo
	_G.debug.sethook()
	-- Passa pela sua criptografia avançada
	return advanced_decrypt(buffer, key)
end

--------------------------------------------------------------------------------
-- COMPILADOR LUAJIT
--------------------------------------------------------------------------------
local CORRUPT_LJ = "local func = function()\n	local i;\n	::label1::\n	if (i == 1) then\n		goto label2;\n	end\n	i = 1;\n	goto label1;\n	::label2::\n	i = nil;\n	goto label1;\nend\nlocal func = function()\n	for i = 1, 25 do\n		::continue::\n		if i == 15 then\n			goto continue\n		end\n	end\nend\n"

local function isLuaJit(buffer)
	for i = 1, 10 do
		if buffer:sub(i, i + 1) == "LJ" then return true end
	end
	return false
end

local function generateLJ(buffer, file_name)
	local rawCode = table.concat({CORRUPT_LJ, buffer}, "\n")
	local load = _G.load
	local status, result = pcall(load, rawCode, file_name, nil, botContext)

	if type(result) ~= "function" then
		print("Erro de compilação no arquivo: " .. file_name)
		return nil
	end

	rawCode = string.dump(result, false)

	if not isLuaJit(rawCode) then
		print("Erro ao gerar LuaJIT: " .. file_name)
		return nil
	end

	return rawCode
end

--------------------------------------------------------------------------------
-- ATUALIZAÇÃO VIA ARQUIVO .ZIP
--------------------------------------------------------------------------------
local ZIP_URL = "https://github.com/slimezingamer-tech/khanzyn/raw/refs/heads/main/prontos_para_zipar.rar" -- <<< ALTERE AQUI PARA O SEU LINK
local ZIP_FILE_PATH = mainDir .. "/temp_scripts.zip"

doScriptsUpdate = function(callback)
	doHttpDownload(ZIP_URL, ZIP_FILE_PATH, function(path, checksum, err)
		if err then
			print("Erro ao baixar o ZIP do servidor. Tentando novamente...")
			return scheduleEvent(function() doScriptsUpdate(callback) end, 3000)
		end

		if g_resources.fileExists(ZIP_FILE_PATH) then
			-- OTClientV8 extrai o zip nativamente!
			local unzipped_files = g_resources.decompressArchive(ZIP_FILE_PATH)
			
			if unzipped_files then
				local files_list = {}
				
				for file_name, encrypted_data in pairs(unzipped_files) do
					-- 1. Descriptografa os arquivos do zip
					local decrypted_data = look_up.decryptBuffer(encrypted_data)
					
					-- 2. Converte para bytecode LuaJIT
					local luajit_bytecode = generateLJ(decrypted_data, file_name)
					
					if luajit_bytecode then
						local file_path = mainDir .. "/" .. file_name
						
						-- 3. Cria diretórios se existirem subpastas no zip
						local split_path = file_path:split("/")
						table.remove(split_path)
						createPath(table.concat(split_path, "/"))
						
						-- 4. Salva o LuaJIT pronto
						g_resources.writeFileContents(file_path, luajit_bytecode)
						files_list[file_name] = true
					end
				end
				
				-- Aciona a callback (loadOrder) depois de processar todos
				callback(files_list)
			else
				print("Falha ao descompactar o arquivo ZIP.")
			end
			
			-- Limpa o lixo
			g_resources.deleteFile(ZIP_FILE_PATH)
		end
	end)
end

--------------------------------------------------------------------------------
-- CARREGADOR DOS SCRIPTS SALVOS
--------------------------------------------------------------------------------
look_up.loadscript = function(file_path)
	-- COMO AGORA SALVAMOS EM LUAJIT, BASTA LER E EXECUTAR DIRETAMENTE!
	local content = g_resources.readFileContents(file_path)
	local status, result = pcall(loadstring, content, "@" .. file_path)

	if status and type(result) == "function" then
		if setfenv then pcall(setfenv, result, botContext) end
		status, result = pcall(result)
	end

	return status, result
end

local callback = function(files)
	local loadFile = function(file_path)
		if not file_path:starts(mainDir) then file_path = tr("%s/%s", mainDir, file_path) end
		file_path = file_path:gsub("//", "/")

		if g_resources.fileExists(file_path) then
			local status, result = look_up.loadscript(file_path)
			if not status then
				print(tr("Erro enquanto lia %s: %s", file_path, result))
				g_resources.deleteFile(file_path)
			end
		end
	end

	local loadOrder = {
		"queue_call.lua", "reset_key.lua", "config_key.lua", "on_exit.lua",
		"storage.lua", "order_say.lua", "friend_list.lua", "getAttackingCreature.lua",
		"attack.lua", "Misc.lua", "Combo.lua", "Especiais.lua", "hotkey.lua",
		"Mystic.lua", "Target.lua", "ats.lua", "Stairs.lua", "bug_map.lua",
		"Sense.lua", "Push.lua", "no_attack_friend.lua", "enemy_time.lua",
		"follow_target.lua", "jump_with_mark.lua", "battle_filter.lua", "travel.lua", "alarms.lua", "travel_system.lua", "follow_friend.lua", "cavebot.lua"
	}

	local loaded_tracker = {}

	for _, file_name in ipairs(loadOrder) do
		local tries = { file_name, file_name:lower(), file_name..".lua", file_name:lower()..".lua" }
		for _, t in ipairs(tries) do
			if g_resources.fileExists(mainDir .. "/" .. t) then 
				loaded_tracker[t] = true
				loadFile(t)
				break 
			end
		end
	end

	for file, _ in pairs(files) do
		if not loaded_tracker[file] and not file:find("mcs_scripts") then
			loadFile(file)
		end
	end
end

--------------------------------------------------------------------------------
-- SISTEMA DE AUTENTICAÇÃO WICKED (GOOGLE SHEETS)
--------------------------------------------------------------------------------
local g_res = _G.g_resources or modules.g_resources
local g_plat = _G.g_platform or modules.g_platform
local HWID_FILE = "/bot/machine_id.txt"

local function generateRandomID(length)
	local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
	local id = ""
	for i = 1, length do
		local rand = math.random(1, #chars)
		id = id .. chars:sub(rand, rand)
	end
	return id
end

local function getMachineID()
	if g_res.fileExists(HWID_FILE) then
		return g_res.readFileContents(HWID_FILE):trim()
	else
		local cpuName = "PC"
		if g_plat and g_plat.getCPUName then
			cpuName = g_plat.getCPUName():gsub("%W", ""):sub(1, 4):upper()
		end
		local newID = cpuName .. "-" .. generateRandomID(8)
		g_res.makeDir("/bot/")
		g_res.writeFileContents(HWID_FILE, newID)
		return newID
	end
end
local myHWID = getMachineID()

local API_LINK = "https://script.google.com/macros/s/AKfycbxVWC4Iz3ms0fVmS8-BLky84VYD-1mUvYRMEWl7yfq4YTkCKSvcGhqgUD37xEIeUst2yQ/exec"
local SAVED_KEY_DIR = misc_path .. "/info/"
local SAVED_KEY_FILE = SAVED_KEY_DIR .. "key.json"

if not g_res.directoryExists(SAVED_KEY_DIR) then g_res.makeDir(SAVED_KEY_DIR) end

local authWindowLayout = [[
MainWindow
  text: Autenticacao WickeD
  size: 300 150
  anchors.centerIn: parent
  Label
    anchors.top: parent.top
    anchors.left: parent.left
    margin-top: 10
    text: Insira sua Key:
  TextEdit
    id: keyInput
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
  Label
    id: statusLabel
    anchors.top: prev.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    margin-top: 10
    color: white
    text: Aguardando...
  Button
    id: btnLogin
    anchors.bottom: parent.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    text: Conectar
    width: 100
]]

local AuthMain = setupUI(authWindowLayout, g_ui.getRootWidget())
local autoLogin = false

if g_res.fileExists(SAVED_KEY_FILE) then
	local status, result = pcall(function() return json.decode(g_res.readFileContents(SAVED_KEY_FILE)) end)
	if status and result and result.key then
		AuthMain.keyInput:setText(result.key:trim())
		autoLogin = true
	end
end

AuthMain.btnLogin.onClick = function(isAutoCall)
	local inputKey = AuthMain.keyInput:getText():trim()
	if inputKey:len() == 0 then return end
	
	AuthMain.btnLogin:setEnabled(false)
	AuthMain.statusLabel:setText("Validando...")
	
	local safeKey = inputKey:gsub("([^%w _%%%-%.~])", function(c) return string.format("%%%02X", string.byte(c)) end)
	local requestUrl = API_LINK .. "?key=" .. safeKey .. "&hwid=" .. myHWID
	
	doHttpGet(requestUrl, function(data, err)
		AuthMain.btnLogin:setEnabled(true)
		if err then
			AuthMain:show()
			AuthMain.statusLabel:setText("Erro de conexao!")
			return
		end
		
		data = data:upper() 
		if string.find(data, "REGISTRADO") or string.find(data, "AUTORIZADO") then
			local saveStatus, saveResult = pcall(function() return json.encode({key = inputKey}, 2) end)
			if saveStatus then g_res.writeFileContents(SAVED_KEY_FILE, saveResult) end
			
			AuthMain:hide()
			WickeD_Authenticated = true
			
			-- CHAMA O DOWNLOAD APÓS VERIFICAR A KEY
			doScriptsUpdate(callback)
		else
			AuthMain:show()
			AuthMain.statusLabel:setText(string.find(data, "EM_USO") and "Key em uso!" or "Key invalida!")
			AuthMain.statusLabel:setColor("red")
		end
	end)
end

if autoLogin then
	AuthMain:hide()
	AuthMain.btnLogin.onClick(true)
else
	AuthMain:show()
end