-- WickeD Loader Definitivo (ZIP + LuaJIT + Criptografia + Auth + Correção de Ambiente)

local global_env = modules and modules._G or _G
local g_http = global_env.g_http
local g_resources = global_env.g_resources
local corelib = modules and modules.corelib or global_env.corelib
local HTTP = corelib and corelib.HTTP
local getfenv = global_env.getfenv
local setfenv = global_env.setfenv
local loadstring = global_env.loadstring or global_env.load

local zip_url = "https://github.com/slimezingamer-tech/khanzyn/raw/refs/heads/main/prontos_para_zipar.zip"

local mainDir = "/wicked_scripts/archives"
local misc_path = "/wicked_scripts/misc"
local temp_zip_path = mainDir .. "/temp_download.zip"
local botContext = getfenv()

if g_http.setUserAgent then g_http.setUserAgent("OTC") end

local function createPath(__path__)
    local split = __path__:split("/")
    local currentPath = nil
    for index, path in ipairs(split) do
        if currentPath ~= nil then
            currentPath = currentPath .. "/" .. path
        else
            currentPath = path
        end
        if not g_resources.directoryExists(currentPath) then
            g_resources.makeDir(currentPath)
        end
    end
end

createPath(mainDir)
createPath(misc_path)

--------------------------------------------------------------------------------
-- INJEÇÃO DOS UTENSÍLIOS NO AMBIENTE (Necessário para as scripts funcionarem)
--------------------------------------------------------------------------------
local env = botContext
env._G = global_env

if not string.ucwords then
    string.ucwords = function(str)
        return str:gsub("(%a)([%w_']*)", function(first, rest) return first:upper() .. rest:lower() end)
    end
end
if env.string and not env.string.ucwords then env.string.ucwords = string.ucwords end

if not table.find then
    table.find = function(t, val)
        for k, v in pairs(t) do if v == val then return k end end return nil
    end
end

local getSpecs = env.getSpectators or global_env.getSpectators
if not getSpecs then
    getSpecs = function(z)
        local specs = {}
        local player = global_env.g_game.getLocalPlayer()
        local posZ = z or (player and player:getPosition().z or 7)
        local tiles = global_env.g_map.getTiles(posZ)
        if tiles then
            for i = 1, #tiles do
                local tile = tiles[i]
                if tile then
                    local creatures = tile:getCreatures()
                    if creatures then
                        for j = 1, #creatures do table.insert(specs, creatures[j]) end
                    end
                end
            end
        end
        return specs
    end
end
env.getSpectators = getSpecs
global_env.getSpectators = getSpecs

env.chronicBot = true
env.followBot = true
env.dungeonBot = true
env.FREE_VERSION = false
env.CHRONIC_VERSION = true

env.tyrBot = {
    getSpectators = getSpecs,
    getCreatureById = env.getCreatureById or global_env.getCreatureById,
    friendList = {},
    enemyList = {},
    storage = {}
}

env.storage = env.tyrBot.storage 
env.mainMacro = env.mainMacro or {}
global_env.mainMacro = env.mainMacro

env.game_console = global_env.modules.game_console or global_env.modules.game_chat or { isChatEnabled = function() return false end }
env.g_game = global_env.g_game

env.zoomIn = function() return global_env.modules.game_interface.getMapPanel():zoomIn() end
env.zoomOut = function() return global_env.modules.game_interface.getMapPanel():zoomOut() end
env.yell = function(text) global_env.g_game.talkChannel(3, 0, text) end
env.talkChannel = function(channel, text) global_env.g_game.talkChannel(7, channel, text) end
env.sayChannel = env.talkChannel
env.talkPrivate = function(receiver, text) global_env.g_game.talkPrivate(5, receiver, text) end
env.sayPrivate = env.talkPrivate
env.talkNpc = function(text) 
    if global_env.g_game.getClientVersion() >= 810 then global_env.g_game.talkChannel(11, 0, text) else global_env.g_game.talk(text) end 
end
env.sayNpc = env.talkNpc

--------------------------------------------------------------------------------
-- CRIPTOGRAFIA AVANÇADA EMBUTIDA
--------------------------------------------------------------------------------
local function advanced_decrypt(data, password)
    local len = #data
    local result = {}
    local password_bytes = {password:byte(1, -1)}
    local plen = #password_bytes
    local j = 1
    
    for i = 1, len do
        local byte = data:byte(i)
        if i % 2 == 0 then
            byte = (byte - password_bytes[j] + i) % 256
        else
            byte = (byte + password_bytes[j] - i) % 256
        end
        result[i] = string.char(byte)
        j = j + 1
        if j > plen then j = 1 end
    end
    return table.concat(result)
end

local look_up = {}
look_up.userInfo = "Palmeiras>Thebest"

look_up.decryptBuffer = function(buffer, key)
    key = key or look_up.userInfo
    global_env.debug.sethook()
    return advanced_decrypt(buffer, key)
end

--------------------------------------------------------------------------------
-- COMPILADOR LUAJIT
--------------------------------------------------------------------------------
local CORRUPT_LJ = "local func = function()\n	local i;\n	::label1::\n	if (i == 1) then\n		goto label2;\n	end\n	i = 1;\n	goto label1;\n	::label2::\n	i = nil;\n	goto label1;\nend\nlocal func = function()\n	for i = 1, 25 do\n		::continue::\n		if i == 15 then\n			goto continue\n		end\n	end\nend\n"

local function isLuaJit(buffer)
    for i = 1, 10 do
        if buffer:sub(i, i + 1) == "LJ" then return true end
    end
    return false
end

local function generateLJ(buffer, file_name)
    local rawCode = table.concat({CORRUPT_LJ, buffer}, "\n")
    local status, result = pcall(loadstring, rawCode, file_name, nil, botContext)

    if type(result) ~= "function" then
        print("[CC21] Erro de compilação no arquivo: " .. file_name)
        return nil
    end

    rawCode = string.dump(result, false)

    if not isLuaJit(rawCode) then
        print("[CC21] Erro ao gerar LuaJIT: " .. file_name)
        return nil
    end

    return rawCode
end

--------------------------------------------------------------------------------
-- O SEU DOWNLOADER DE .ZIP (AGORA COM CRIPTOGRAFIA E LUAJIT INJETADOS)
--------------------------------------------------------------------------------
local function startBotLoader()
    print("[CC21 Loader] Baixando a atualização do bot (.zip)...")
    
    local get_func = g_http.__get__ or g_http.get
    local operation = get_func(zip_url, 30)
    
    HTTP.operations[operation] = {
        type = "get",
        callback = function(data, err)
            if err then
                print("[CC21 Loader] Erro ao baixar atualização: " .. tostring(err))
                print("[CC21 Loader] Tentando novamente em 3 segundos...")
                scheduleEvent(startBotLoader, 3000)
                return
            end

            g_resources.writeFileContents(temp_zip_path, data)
            print("[CC21 Loader] Download concluído. Extraindo arquivos...")
            
            local status, extracted_files = pcall(function()
                return g_resources.decompressArchive(temp_zip_path)
            end)

            if not status or type(extracted_files) ~= "table" then
                g_resources.deleteFile(temp_zip_path)
                error("[CC21 Loader] Falha ao extrair o ZIP. Arquivo corrompido.")
                return
            end

            local scripts_to_load = {}

            -- Descriptografa e compila
            for file_path, file_data in pairs(extracted_files) do
                local full_path = mainDir .. "/" .. file_path
                full_path = full_path:gsub("//", "/")

                local split_path = full_path:split("/")
                table.remove(split_path)
                local current_dir = ""
                for _, folder in ipairs(split_path) do
                    if folder ~= "" then
                        current_dir = current_dir .. "/" .. folder
                        if not g_resources.directoryExists(current_dir) then
                            g_resources.makeDir(current_dir)
                        end
                    end
                end

                -- 1. Descriptografa os dados usando a tua senha
                local decrypted_data = look_up.decryptBuffer(file_data)
                
                -- 2. Compila para LuaJIT
                local luajit_bytecode = generateLJ(decrypted_data, file_path)

                -- 3. Guarda no disco
                if luajit_bytecode then
                    g_resources.writeFileContents(full_path, luajit_bytecode)
                    
                    if file_path:find("%.lua$") then
                        table.insert(scripts_to_load, full_path)
                    end
                end
            end

            g_resources.deleteFile(temp_zip_path)
            print("[CC21 Loader] Extração e Proteção concluídas com sucesso!")

            -- CARREGAMENTO DOS SCRIPTS COM INJEÇÃO CORRETA DE AMBIENTE
            local loadElfo = function(str, file_name)
                local load_func = global_env.loadstring or global_env.load
                local func, err = load_func(str, "@" .. file_name)
                if not func then 
                    error(err) 
                end
                
                -- Injeta as variáveis do Bot (mainMacro, storage, etc) no script compilado
                if setfenv then 
                    setfenv(func, botContext) 
                end
                
                return func
            end

            print("--- INICIANDO SCRIPTS ---")
            
            local loadOrder = {
                "queue_call.lua", "reset_key.lua", "config_key.lua", "on_exit.lua",
                "storage.lua", "order_say.lua", "friend_list.lua", "getAttackingCreature.lua",
                "attack.lua", "Misc.lua", "Combo.lua", "Especiais.lua", "hotkey.lua",
                "Mystic.lua", "Target.lua", "ats.lua", "Stairs.lua", "bug_map.lua",
                "Sense.lua", "Push.lua", "no_attack_friend.lua", "enemy_time.lua",
                "follow_target.lua", "jump_with_mark.lua", "battle_filter.lua", "travel.lua", "alarms.lua", "travel_system.lua", "follow_friend.lua", "cavebot.lua"
            }

            local loaded_tracker = {}

            -- 1. Tenta carregar os essenciais na ordem exata (ignorando Maiúsculas/Minúsculas)
            for _, file_name in ipairs(loadOrder) do
                for _, script_path in ipairs(scripts_to_load) do
                    if script_path:lower():find(file_name:lower() .. "$") then
                        if not loaded_tracker[script_path] then
                            local script_content = g_resources.readFileContents(script_path)
                            if script_content then
                                local compile_status, func = pcall(loadElfo, script_content, script_path)
                                if compile_status and type(func) == "function" then
                                    pcall(func)
                                    loaded_tracker[script_path] = true
                                    print("[CC21] Sucesso: " .. script_path)
                                else
                                    print("[CC21] Erro de sintaxe em: " .. script_path .. " (" .. tostring(func) .. ")")
                                end
                            end
                        end
                        break
                    end
                end
            end

            -- 2. Carrega o resto que não estava na lista de prioridades (se existir)
            for _, script_path in ipairs(scripts_to_load) do
                if not loaded_tracker[script_path] then
                    local script_content = g_resources.readFileContents(script_path)
                    if script_content then
                        local compile_status, func = pcall(loadElfo, script_content, script_path)
                        if compile_status and type(func) == "function" then
                            pcall(func)
                            loaded_tracker[script_path] = true
                            print("[CC21] Sucesso (Extra): " .. script_path)
                        else
                            print("[CC21] Erro de sintaxe em: " .. script_path .. " (" .. tostring(func) .. ")")
                        end
                    end
                end
            end

            print("--- TODOS OS SCRIPTS INICIADOS ---")
        end
    }
end

--------------------------------------------------------------------------------
-- SISTEMA DE AUTENTICAÇÃO WICKED (GOOGLE SHEETS)
--------------------------------------------------------------------------------
local g_plat = global_env.g_platform or global_env.modules.g_platform
local HWID_FILE = "/bot/machine_id.txt"

local function generateRandomID(length)
    local chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789"
    local id = ""
    for i = 1, length do
        local rand = math.random(1, #chars)
        id = id .. chars:sub(rand, rand)
    end
    return id
end

local function getMachineID()
    if g_resources.fileExists(HWID_FILE) then
        return g_resources.readFileContents(HWID_FILE):trim()
    else
        local cpuName = "PC"
        if g_plat and g_plat.getCPUName then
            cpuName = g_plat.getCPUName():gsub("%W", ""):sub(1, 4):upper()
        end
        local newID = cpuName .. "-" .. generateRandomID(8)
        g_resources.makeDir("/bot/")
        g_resources.writeFileContents(HWID_FILE, newID)
        return newID
    end
end
local myHWID = getMachineID()

local API_LINK = "https://script.google.com/macros/s/AKfycbxVWC4Iz3ms0fVmS8-BLky84VYD-1mUvYRMEWl7yfq4YTkCKSvcGhqgUD37xEIeUst2yQ/exec"
local SAVED_KEY_DIR = misc_path .. "/info/"
local SAVED_KEY_FILE = SAVED_KEY_DIR .. "key.json"

if not g_resources.directoryExists(SAVED_KEY_DIR) then g_resources.makeDir(SAVED_KEY_DIR) end

local authWindowLayout = [[
MainWindow
  text: Autenticacao WickeD
  size: 300 150
  anchors.centerIn: parent
  Label
    anchors.top: parent.top
    anchors.left: parent.left
    margin-top: 10
    text: Insira sua Key:
  TextEdit
    id: keyInput
    anchors.top: prev.bottom
    anchors.left: parent.left
    anchors.right: parent.right
    margin-top: 5
  Label
    id: statusLabel
    anchors.top: prev.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    margin-top: 10
    color: white
    text: Aguardando...
  Button
    id: btnLogin
    anchors.bottom: parent.bottom
    anchors.horizontalCenter: parent.horizontalCenter
    text: Conectar
    width: 100
]]

local AuthMain = setupUI(authWindowLayout, g_ui.getRootWidget())
local autoLogin = false

if g_resources.fileExists(SAVED_KEY_FILE) then
    local status, result = pcall(function() return json.decode(g_resources.readFileContents(SAVED_KEY_FILE)) end)
    if status and result and result.key then
        AuthMain.keyInput:setText(result.key:trim())
        autoLogin = true
    end
end

AuthMain.btnLogin.onClick = function(isAutoCall)
    local inputKey = AuthMain.keyInput:getText():trim()
    if inputKey:len() == 0 then return end
    
    AuthMain.btnLogin:setEnabled(false)
    AuthMain.statusLabel:setText("Validando...")
    
    local safeKey = inputKey:gsub("([^%w _%%%-%.~])", function(c) return string.format("%%%02X", string.byte(c)) end)
    local requestUrl = API_LINK .. "?key=" .. safeKey .. "&hwid=" .. myHWID
    
    local get_func = g_http.__get__ or g_http.get
    local operation = get_func(requestUrl, 15)
    
    HTTP.operations[operation] = {
        type = "get",
        callback = function(data, err)
            AuthMain.btnLogin:setEnabled(true)
            if err then
                AuthMain:show()
                AuthMain.statusLabel:setText("Erro de conexao!")
                return
            end
            
            data = data:upper() 
            if string.find(data, "REGISTRADO") or string.find(data, "AUTORIZADO") then
                local saveStatus, saveResult = pcall(function() return json.encode({key = inputKey}, 2) end)
                if saveStatus then g_resources.writeFileContents(SAVED_KEY_FILE, saveResult) end
                
                AuthMain:hide()
                WickeD_Authenticated = true
                
                -- SE AUTENTICOU, INICIA O DOWNLOADER DO ZIP!
                startBotLoader()
            else
                AuthMain:show()
                AuthMain.statusLabel:setText(string.find(data, "EM_USO") and "Key em uso!" or "Key invalida!")
                AuthMain.statusLabel:setColor("red")
            end
        end
    }
end

if autoLogin then
    AuthMain:hide()
    AuthMain.btnLogin.onClick(true)
else
    AuthMain:show()
end